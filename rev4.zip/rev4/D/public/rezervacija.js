var datumTrenutni = new Date();
var mjesecTrenutni = datumTrenutni.getMonth();

Kalendar.iscrtajKalendar(document.getElementById("kalendar"), mjesecTrenutni);

document.getElementById("btnNaredni").addEventListener("click",naprijedMjesec);
document.getElementById("btnPrethodni").addEventListener("click", nazadMjesec);

document.getElementById("frmSala").addEventListener("change", pozoviInicijalizaciju);
document.getElementById("frmPocetak").addEventListener("change", pozoviInicijalizaciju);
document.getElementById("frmKraj").addEventListener("change", pozoviInicijalizaciju);


/*
var zauzecaJson = Pozivi.ucitajPodatkeAjax();
var periodicnaZauzecaData = zauzecaJson.periodicnaZauzeca;
var vanrednaZauzecaData = zauzecaJson.vanrednaZauzeca;
*/

/*
var periodicnaZauzecaData = [ { "dan":1, "semestar":"zimski", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" }, 
							  { "dan":3, "semestar":"zimski", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							  { "dan":4, "semestar":"ljetni", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" }] ;
var vanrednaZauzecaData = [ { "datum":"15.11.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"17.11.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"26.5.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac" },
							{ "datum":"25.3.2019", "pocetak":"15:00", "kraj":"16:00", "naziv":"test naziv", "predavac":"test predavac"}];
							*/

function dobaviPodatke(dbData) {
	
	var periodicnaZauzecaData = [];
	var vanrednaZauzecaData = [];
	
	var zauzecaJson = Pozivi.ucitajPodatkeBazaAjax();
	console.log (zauzecaJson);
	
	for(i=0; i<zauzecaJson.length; i++) {	
	
			if(zauzecaJson[i]["terminRezervacija.redovni"]==1) {
				
				var temp = {};
				temp["dan"] = zauzecaJson[i]["terminRezervacija.dan"];
				temp["semestar"] = zauzecaJson[i]["terminRezervacija.semestar"];
				temp["pocetak"] = zauzecaJson[i]["terminRezervacija.pocetak"];
				temp["kraj"] = zauzecaJson[i]["terminRezervacija.kraj"];
				temp["naziv"] = zauzecaJson[i]["salaRezervacija.naziv"];
				temp["predavac"] = zauzecaJson[i]["osobaRezervacija.ime"] + " " + zauzecaJson[i]["osobaRezervacija.prezime"];
				
				periodicnaZauzecaData.push(temp);
				console.log(temp);
			}
			
			if(zauzecaJson[i]["terminRezervacija.redovni"]==0) {
				
				var temp = {};
				temp["datum"] = zauzecaJson[i]["terminRezervacija.datum"];
				temp["pocetak"] = zauzecaJson[i]["terminRezervacija.pocetak"];
				temp["kraj"] = zauzecaJson[i]["terminRezervacija.kraj"];
				temp["naziv"] = zauzecaJson[i]["salaRezervacija.naziv"];
				temp["predavac"] = zauzecaJson[i]["osobaRezervacija.ime"] + " " + zauzecaJson[i]["osobaRezervacija.prezime"];
				
				vanrednaZauzecaData.push(temp);
				console.log(temp);
			}
	}
	
	dbData.periodicna = periodicnaZauzecaData;
	dbData.vanredna = vanrednaZauzecaData;
	
}

var dbData = {periodicna : "" , vanredna : ""};
dobaviPodatke(dbData);

// popunjavanje osoba
var osobeData = Pozivi.ucitajOsobe();
for(i=0; i<osobeData.length; i++) {	
	var option = document.createElement("option");
	option.text = osobeData[i]["ime"] + " " + osobeData[i]["prezime"];
	option.value = osobeData[i]["id"];
	var select = document.getElementById("frmOsoba");
	select.appendChild(option);
}

// popunjavanje sala
var saleData = Pozivi.ucitajSale();
for(i=0; i<saleData.length; i++) {	
	var option = document.createElement("option");
	option.text = saleData[i]["naziv"];
	option.value = saleData[i]["id"];
	var select = document.getElementById("frmSala");
	select.appendChild(option);
}

Kalendar.ucitajPodatke(dbData.periodicna, dbData.vanredna);
Kalendar.podesiAktivniMjesec(mjesecTrenutni);
//Kalendar.inicijalizirajKalendar();
 

function rezervisi() {
	var cssKlasa = this.getAttribute("class");
	
	var danDjeca = this.children;
	var dan = danDjeca[0].innerText;
	
	var pozicijaDana = false;
	var slobodanDan = false;
	
	// da li listner da poziciji koja je dan u kalendaru
	if(cssKlasa=="dan") {
		pozicijaDana = true;
		//da li je dan slobodan ili nije, tj da li moguca rezervacija
		var danDjeca = this.children;
		if(danDjeca[1].getAttribute("class") == "statusDan slobodna" ) {
			slobodanDan = true;
		}	
	}
	
	if (pozicijaDana && slobodanDan) {
		
		if (confirm('Da li zelite da rezervisete ovaj termin?')) {
			
			var salaId = document.getElementById("frmSala").value;
			var periodicna = document.getElementById("frmPeriodicna").checked;
			var pocetak = document.getElementById("frmPocetak").value;
			var kraj = document.getElementById("frmKraj").value;
			var osoba = document.getElementById("frmOsoba").value;
			
			var selectSala = document.getElementById("frmSala");
			var salaNaziv = selectSala.options[salaId-1].text;
			
			//var datumTrenutni = new Date();
			var godina = datumTrenutni.getFullYear();
			
			var mjesecNazivNizObj = document.getElementsByClassName("mjesecNaslov");
			var mjesecNazivObj = mjesecNazivNizObj[0];
			var mjesecNazivObjDjeca = mjesecNazivObj.children;
			var mjesecNaziv = mjesecNazivObjDjeca[0].innerText;
			
			var mjesec = Kalendar.redniBrojMjeseca(mjesecNaziv);
			
			if (pocetak == "" || kraj == "") {
				alert("Nedostaju podaci.");
			} else if ( Date.parse('01/01/2011 ' + pocetak) >= Date.parse('01/01/2011 ' + kraj) ) {
				alert("Vrijeme kraja ne moze biti prije vremena pocetka.");
			} else {
				// odgovor json
				var jsonOdgovor = Pozivi.rezervacija(dan, mjesec, godina, salaId, periodicna, pocetak, kraj, osoba, salaNaziv);
				if (jsonOdgovor.greska == "OK") {
					
					var periodicnaZauzecaData = jsonOdgovor.periodicnaZauzeca;
					var vanrednaZauzecaData = jsonOdgovor.vanrednaZauzeca;
					Kalendar.ucitajPodatke(periodicnaZauzecaData, vanrednaZauzecaData);
					pozoviInicijalizaciju();	
					
				} else {
					alert(jsonOdgovor.greska);

					var periodicnaZauzecaData = jsonOdgovor.periodicnaZauzeca;
					var vanrednaZauzecaData = jsonOdgovor.vanrednaZauzeca;
					Kalendar.ucitajPodatke(periodicnaZauzecaData, vanrednaZauzecaData);					
					pozoviInicijalizaciju();
				}
			}
			
		} 
		
	} else {
		alert("Vec je izvrsena rezervacija.");
	}
	
}

var elementiDani = document.getElementsByClassName("dan");
for (var i = 0; i < elementiDani.length; i++) {
    elementiDani[i].addEventListener('click', rezervisi, false);
}

function pozoviInicijalizaciju() {
	var salaId = document.getElementById("frmSala").value;
	console.log("SALA ID:" + salaId);
	var periodicna = document.getElementById("frmPeriodicna").checked;
	var pocetak = document.getElementById("frmPocetak").value;
	var kraj = document.getElementById("frmKraj").value;
	
	var selectSala = document.getElementById("frmSala");
	var sala = selectSala.options[salaId-1].text;
	
	Kalendar.inicijalizirajKalendar(sala, pocetak, kraj);	
	
}

function naprijedMjesec() {
	Kalendar.aktivniMjesecNaprijed();
	pozoviInicijalizaciju();
}

function nazadMjesec() {
	Kalendar.aktivniMjesecNazad();
	pozoviInicijalizaciju();
}
var podaci = Pozivi.ucitajOsobePoSalama();
document.getElementById("sadrzaj").innerHTML = podaci;

setInterval(function(){ 

	var podaci = Pozivi.ucitajOsobePoSalama();
	document.getElementById("sadrzaj").innerHTML = podaci;

}, 30000);
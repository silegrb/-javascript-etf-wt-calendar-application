//import { Pozivi } from './Pozivi.js';
let Pozivi = (function() {
    //FUNKCIJA KOJOM SALJEMO PODATKE U NAS MODUL KALENDAR(GOTOVA)
    function ucitavanjePodatakaImpl() {
        var JSONrez;
        //console.log("Za test");
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                JSONrez = JSON.parse(this.responseText);
                console.log(JSONrez);

                Kalendar.ucitajPodatke(JSONrez.periodicna, JSONrez.vanredna);
                //OSTAVI ZA KASNIJE
                
            }
        };
        xhttp.open("GET", "/zauzeca.json", true);
        xhttp.send();
    }
    
    

    function opcijaRezervisanjaImpl(event) {
        
        var nasePolje = event.target;
        var daILIne = confirm("Želite li rezervisati ovaj termin?");
        if(daILIne == true) { 
                    var moze = true;
                    //Ako je ispunjen ovaj uslov ne moze se rezervisati sala
                    if(nasePolje.style.backgroundImage == 'linear-gradient(white 70%, red 30%)') {
                        moze = false;
                        console.log("Ne moze!");
                    }

                    
                    var jeLi = true;
                    if(document.getElementById("per").checked == true) {
                        jeLi = true;
                    } else {
                        jeLi = false;
                    }

                    
                    var sala;
                    var pocetak;
                    var kraj;
                    var datum;
                    var data1;
                    var predavac = document.getElementById("selectOsoblje").options[document.getElementById("selectOsoblje").selectedIndex].value;
                    pocetak = document.getElementById("poc").value;
                        kraj = document.getElementById("kra").value;
                        sala = document.getElementById("selectSale").options[document.getElementById("selectSale").selectedIndex].value;
                        
                        
                        var mjesec = document.getElementById("mjesecLabel").innerText;
                        
                        if(mjesec == "Decembar") {
                            mjesec = "12";
                        } else if(mjesec == "Novembar") {
                            mjesec = "11";
                        } else if(mjesec == "Oktobar") {
                            mjesec = "10";
                        } else if(mjesec == "Septembar") {
                            mjesec = "9";
                        } else if(mjesec == "August") {
                            mjesec = "8";
                        } else if(mjesec == "Juli") {
                            mjesec = "7";
                        } else if(mjesec == "Juni") {
                            mjesec = "6";
                        } else if(mjesec == "Maj") {
                            mjesec = "5";
                        } else if(mjesec == "April") {
                            mjesec = "4";
                        } else if(mjesec == "Mart") {
                            mjesec = "3";
                        } else if(mjesec == "Februar") {
                            mjesec = "2";
                        } else if(mjesec == "Januar") {
                            mjesec = "1";
                        } 

                        //Za nas dan da odredimo
                        var dann;
                        
                        if(nasePolje.innerText == "1") {
                            dann = "01"
                        } else if(nasePolje.innerText == "2") {
                            dann = "02"
                        } else if(nasePolje.innerText == "3") {
                            dann = "03"
                        } else if(nasePolje.innerText == "4") {
                            dann = "04"
                        } else if(nasePolje.innerText == "5") {
                            dann = "05"
                        } else if(nasePolje.innerText == "6") {
                            dann = "06"
                        } else if(nasePolje.innerText == "7") {
                            dann = "07"
                        } else if(nasePolje.innerText == "8") {
                            dann = "08"
                        } else if(nasePolje.innerText == "9") {
                            dann = "09"
                        } else if(nasePolje.innerText == "10") {
                            dann = "10"
                        } else if(nasePolje.innerText == "11") {
                            dann = "11"
                        } else if(nasePolje.innerText == "12") {
                            dann = "12"
                        } else if(nasePolje.innerText == "13") {
                            dann = "13"
                        } else if(nasePolje.innerText == "14") {
                            dann = "14"
                        } else if(nasePolje.innerText == "15") {
                            dann = "15"
                        } else if(nasePolje.innerText == "16") {
                            dann = "16"
                        } else if(nasePolje.innerText == "17") {
                            dann = "17"
                        } else if(nasePolje.innerText == "18") {
                            dann = "18"
                        } else if(nasePolje.innerText == "19") {
                            dann = "19"
                        } else if(nasePolje.innerText == "20") {
                            dann = "20"
                        } else if(nasePolje.innerText == "21") {
                            dann = "21"
                        } else if(nasePolje.innerText == "22") {
                            dann = "22"
                        } else if(nasePolje.innerText == "23") {
                            dann = "23"
                        } else if(nasePolje.innerText == "24") {
                            dann = "24"
                        } else if(nasePolje.innerText == "25") {
                            dann = "25"
                        } else if(nasePolje.innerText == "26") {
                            dann = "26"
                        } else if(nasePolje.innerText == "27") {
                            dann = "27"
                        } else if(nasePolje.innerText == "28") {
                            dann = "28"
                        } else if(nasePolje.innerText == "29") {
                            dann = "29"
                        } else if(nasePolje.innerText == "30") {
                            dann = "30"
                        } else if(nasePolje.innerText == "31") {
                            dann = "31"
                        }

                        var currentyear = new Date().getFullYear();
                        datum = dann + '.' + mjesec + '.' + currentyear;
                        if(jeLi) {
                            data1 = JSON.stringify({"datum": datum, "pocetak": pocetak, "kraj": kraj, "naziv": sala, "predavac": predavac, "vrsta": true});
                        }else {
                            data1 = JSON.stringify({"datum": datum, "pocetak": pocetak, "kraj": kraj, "naziv": sala, "predavac": predavac, "vrsta": false});
                        }
                        
                    //Ako nije zauzet termin gradi se JSON podatak
                    if(moze) {
                        
                        //OVO JE DA SE UBACI U BAZU//GOTOVO//RADI
                        var xhttp5 = new XMLHttpRequest();
                        xhttp5.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {   
                            }
                        };
                        xhttp5.open("POST", "/rezervisi", true);
                        xhttp5.setRequestHeader("Content-Type", "application/json");
                        xhttp5.send(data1);

                        //OVO JE DA UBACI U JSON
                        var xhttp2 = new XMLHttpRequest();
                        xhttp2.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {                           
                                pozivaUcit();
                                Kalendar.obojiZauzeca(document.getElementsByClassName("Kalendar"), parseInt(mjesec)-1, document.getElementById("selectSale").options[document.getElementById("selectSale").selectedIndex].value, document.getElementById("poc").value, document.getElementById("kra").value);
                                nasePolje.style.backgroundImage = 'linear-gradient(white 70%, red 30%)';
                            }
                        };
                        xhttp2.open("POST", "/zauzeca.json", true);
                        xhttp2.setRequestHeader("Content-Type", "application/json");
                        xhttp2.send(data1);
                    } else {
                        var xhttp3 = new XMLHttpRequest();
                        xhttp3.onreadystatechange = function() {
                            if (this.readyState == 4 && this.status == 200) {
                                
                                var teks = this.responseText;
                                alert("Nije moguće rezervisati salu  jer je osoba " + teks + " rezervisala salu");
                            }
                        };
                        xhttp3.open("POST", "/rezervisiNE", true);
                        xhttp3.setRequestHeader("Content-Type", "application/json");
                        xhttp3.send(data1);
                    }
        }
    }

    //Sluzi za dodavanje u select polje osoblje/GOTOVO JE OVO SKROZ/ZADATAK 1
    function ucitavanjeBazaImpl() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var tekst = xhttp.responseText;
                var tekst1 = tekst.split('\n');
                var broj = 1;
                //U ovoj petlji dodajemo na svako options polje posebno
                for(var i = 0; i < tekst1.length-1; i++) {
                    document.getElementById("prvo" + broj.toString()).innerHTML = tekst1[i];
                    document.getElementById("prvo" + broj.toString()).value = tekst1[i];
                    broj++;
                }
            }
        };
        xhttp.open("GET", "/osoblje", true);
        xhttp.send();
    }

    
    return {
        ucitavanjePodataka: ucitavanjePodatakaImpl,
        opcijaRezervisanja: opcijaRezervisanjaImpl,
        ucitavanjeBaza: ucitavanjeBazaImpl
    }
} ());

window.onload = function() {
    zaOsoblje();
    Kalendar.iscrtajKalendar(document.getElementsByClassName("Kalendar"), datum.getMonth());
    Pozivi.ucitavanjePodataka();
    
    //OVDJE uzimamo citav nas kalendar i dodajemo listenere da mozemo pratiti sta je rezervisano, a sta ne
    var kalendarRef = document.getElementsByClassName("Kalendar");
    //Da uzmemo sve sto ima u kalendaru i stavimo kao jedan niz
    var nodesOfKalendar = kalendarRef[0].childNodes;
    //Uzimamo samo divContainer klasu iz node stabla
    var divContainer = nodesOfKalendar[3];
    //Uzimamo sada svu djecu divContainera
    var djecaDivContainera = divContainer.childNodes;
    for(var dani = 15; dani <= 95; dani+=2) {
        djecaDivContainera[dani].addEventListener('click', Pozivi.opcijaRezervisanja);
    }

    
}

function zaOsoblje() {
    Pozivi.ucitavanjeBaza();
}

function pozivaUcit() {
    Pozivi.ucitavanjePodataka();
}

function opcijaRezervisanja(/*event*/) {
    Pozivi.opcijaRezervisanja(event);
}



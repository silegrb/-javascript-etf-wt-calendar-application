//import { Pozivi } from './Pozivi.js';
let Pozivi = (function() {
    function dobavljanjeImpl() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                console.log("2123");
        };
        xhttp.open("GET", "/osobe", true);
        xhttp.send();

    }
}


    return {
        dobavljanje: dobavljanjeImpl
        
    }
} ());

window.onload = function() {
    Pozivi.dobavljanje();

    setInterval(() => {
        Pozivi.dobavljanje();
    }, 30000);
}

function pozvati() {
    Pozivi.dobavljanje();
}
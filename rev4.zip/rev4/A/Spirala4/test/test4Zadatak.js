const chai = require("chai");
const chaiHttp = require("chai-http");
const db = require('./db.js');
const index = require('./index.js');


let assert = chai.assert;
var sale = [];
var osobe = [];
const { expect } = chai;
chai.use(chaiHttp);
chai.should();
describe('Provjera', function() {
        db.sequelize.sync({force: true}).then(function() {
            //init.inicijalizacija().then(function() {
                //chai.request(index).get('/sale').end((err, res) => {
                    //expect(res).to.have.status(200);
                    //sale = res.body;
                    chai.request(index.app).get('/osoblje').end((err, res) => {
                        console.log(res);
                        //expect(res).to.have.status(200);
                        //osobe = res.body;
                        done();
                    });
            });
        
    

    it("treba vratiti 3 osobe", (done) => {
        chai.request(index.app).get('/osoblje').end((err, res) => {
            //expect(res.status).to.equal(200);
            expect(res.body.length).to.equal(3);
            done();
        });
    });
});
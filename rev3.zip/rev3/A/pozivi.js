let Pozivi = (function () {
	var ajax = new XMLHttpRequest();
	var ucitaneSlike = []; 
	var last;
	var startIndex, endIndex; // indeks prve i zadnje trenutno prikazane slike (u nizu ucitaneSlike)
	

	function ucitajPodatkeImpl (funkcijaUcitavanje) {	
		ajax.onreadystatechange = function () {		
		    if (ajax.readyState == 4 && ajax.status == 200) {
		    	var periodicna = appendDataPeriodicna(JSON.parse(ajax.response));
		    	var vanredna = appendDataVanredna(JSON.parse(ajax.response));
		    	funkcijaUcitavanje(periodicna, vanredna);
		    }
		}

		ajax.open("GET", "http://localhost:8080/zauzeca.json", true);
		ajax.setRequestHeader("Content-Type", "application/json");
		ajax.send();
	}

	function uputiPostZahtjevImpl (dan, periodicna, mjesec, sala, pocetak, kraj, funkcijaBojenje) {
		ajax.onreadystatechange = function () {
			if (ajax.readyState == 4 && ajax.status == 200) {
				if (ajax.response.includes("Greška!")) {
					alert (ajax.response);
				} else {
					var periodicnaNova = appendDataPeriodicna(JSON.parse(ajax.response));
			    	var vanrednaNova = appendDataVanredna(JSON.parse(ajax.response));
					funkcijaBojenje(periodicnaNova, vanrednaNova); // ucitava nova zauzeca i boji zauzeća
				}
			}

		};
		ajax.open("POST", "http://localhost:8080/rezervisi", true);
		ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		ajax.send("dan=" + dan + "&periodicna=" + periodicna + "&mjesec=" + mjesec + "&sala=" + sala + "&pocetak=" + pocetak + "&kraj=" + kraj);
	}

	function ucitajTriSlikeImpl () { 
		var pocetna, krajnja;
		var div = document.getElementById("imgContainer");
		if (ucitaneSlike.length == 0) {
			pocetna = 0;
			krajnja = 3;
			this.startIndex = 0;
			this.endIndex = 3;
		} else {
			if (this.endIndex - this.startIndex == 3) {
				this.endIndex += 3;
				this.startIndex +=3;
			} else if (this.endIndex - this.startIndex == 2) {
				this.endIndex += 2;
				this.startIndex += 3;
			} else if (this.endIndex - this.startIndex == 1) {
				this.endIndex += 1;
				this.startIndex += 3;
			} 
		}
		 // ako nije ucitana prije, posalji ajax zahtjev da ih dobavi
		var pomocna = this.endIndex -3;
		if (ucitaneSlike.length <= pomocna) { 
			if (ucitaneSlike.length != 0) {
				pocetna = ucitaneSlike.length;
				krajnja = pocetna + last;
			}
			ajax.open("GET", "http://localhost:8080/slike?pocetna=" + pocetna + "&krajnja=" + krajnja, true);
			pocetna = encodeURIComponent(pocetna);
			krajnja = encodeURIComponent(krajnja);
			ajax.send();
		} else { // ucitaj iz niza ucitaneSlike
			removeOldImages(div);
			for (var i = this.startIndex; i < this.endIndex; i++) {
				if (ucitaneSlike[i] != undefined) {
					var img = document.createElement("img");
					img.src = ucitaneSlike[i];
					div.appendChild(img);
				} else document.getElementById("sljedeciBtn").disabled = true; 
			}
		}
		
		if (this.startIndex != 0) document.getElementById("prethodniBtn").disabled = false;	
		else { // ucitavanje prvih slika
			document.getElementById("prethodniBtn").disabled = true;
			document.getElementById("sljedeciBtn").disabled = false;
		}

		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) { 		
				if (ajax.response != "[]") { // kada su prikazane zadnje tri slike, ali smo pritisnuli dugme sljedeci, server ce vratiti odgovor "[]"
					var array = ajax.response.split(",");
					if (array.length < 3) document.getElementById("sljedeciBtn").disabled = true; // ako vrati manje od 3 slike, nema ih vise na serveru
					else document.getElementById("sljedeciBtn").disabled = false;
					// ispod se brisu odredjeni znakovi iz array-a jer ga formira u obliku npr. [""etf.png"", ""sarajevo.jpg""] - a nama treba samo dio unutar navodnika da predstavlja clan niza
					array[0] = array[0].slice(0, 0) + array[0].slice(1, array[0].length); // brišemo prvi znak prvog člana tj [ 
					var lastIndex = array.length-1;
					last = lastIndex + 1;
					Pozivi.endIndex = Pozivi.startIndex + last;
					array[lastIndex] = array[lastIndex].slice(0, array[lastIndex].length-1) + array[lastIndex].slice(array[lastIndex].length, array[lastIndex].length); // brišemo zadnji znak u nizu tj ]
					removeOldImages(div);
					for (var i = 0; i < last; i++) {
						var source = array[i].toString().replace(/"/, ""); // obrišemo prvi znak "
						source = source.slice(0, source.length-1) + source.slice(source.length, source.length); // obrišemo zadnji znak "
						var img = document.createElement("img");
						img.src = source;
						div.appendChild(img);
						ucitaneSlike.push(source);
					}
				} else document.getElementById("sljedeciBtn").disabled = true; // ovim oznacavamo da nema vise slika na serveru
				
			}
		};	

	}

	function prikaziPrethodneSlikeImpl() {
		// ova funkcija ce se pozvati tek kada nismo prvi put na stranici, jer je u suprotnom dugme prethodni disabled
		document.getElementById("sljedeciBtn").disabled = false; // cim smo pritisnuli dugme prethodni, mozemo se vratiti naprijed na sljedeci
		// prvo brisemo trenutno prikazane slike
		var div = document.getElementById("imgContainer");
		removeOldImages(div);
		// racunamo indekse unutar niza ucitanih slika kojima trebamo pristupati sada
		if (this.endIndex - this.startIndex == 3) {
			this.endIndex -= 3;
			this.startIndex -=3;
		} else if (this.endIndex - this.startIndex == 2) {
			this.endIndex -= 2;
			this.startIndex -= 3;
		} else if (this.endIndex - this.startIndex == 1) {
			this.endIndex -= 1;
			this.startIndex -= 3;
		} 
		if (this.startIndex == 0) document.getElementById("prethodniBtn").disabled = true;
		else document.getElementById("prethodniBtn").disabled = false;
		//prikazujemo slike
		for (var i = this.startIndex; i < this.endIndex; i++) {
			var img = document.createElement("img");
			img.src = ucitaneSlike[i];
			div.appendChild(img);
		}
	}

	return {
		ucitajPodatke : ucitajPodatkeImpl,
		uputiPostZahtjev : uputiPostZahtjevImpl,
		ucitajTriSlike : ucitajTriSlikeImpl,
		prikaziPrethodneSlike : prikaziPrethodneSlikeImpl
	}
}());

function appendDataPeriodicna (data) {
	var periodicna = [];
	var i;
	for (i = 0; i < data.periodicna.length; i++) {		
		var object = {};
		object["dan"] = data.periodicna[i].dan;
		object["semestar"] = data.periodicna[i].semestar;
		object["pocetak"] = data.periodicna[i].pocetak;
		object["kraj"] = data.periodicna[i].kraj;
		object["naziv"] = data.periodicna[i].naziv;
		object["predavac"] = data.periodicna[i].predavac;
		periodicna.push(object);
	} 
	return periodicna;
}

function appendDataVanredna (data) {
	var vanredna = [];
	var i;
	for (i = 0; i < data.vanredna.length; i++) {
		var object = {};
			object["datum"] = data.vanredna[i].datum;
			object["pocetak"] = data.vanredna[i].pocetak;
			object["kraj"] = data.vanredna[i].kraj;
			object["naziv"] = data.vanredna[i].naziv;
			object["predavac"] = data.vanredna[i].predavac;
			vanredna.push(object);		
	} 
	return vanredna;
}

function ucitaj() {
	Pozivi.ucitajPodatke();
}

function removeOldImages(div) {
	while(div.firstChild) {
		div.removeChild(div.firstChild);
	}
}

function sljedece () {
	Pozivi.ucitajTriSlike();
}

function prethodne () {
	Pozivi.prikaziPrethodneSlike();
	
}
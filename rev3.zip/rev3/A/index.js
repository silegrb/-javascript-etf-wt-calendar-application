const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const url = require('url');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/index.js',function(req,res){
    res.sendFile("/index.js", {root: __dirname});
});
app.get('/',function(req,res){
    res.sendFile("/pocetna.html", {root: __dirname});
});

app.get('/rezervacija.html',function(req,res){
    res.sendFile("/rezervacija.html", {root: __dirname});
});
app.get('/pocetna.html',function(req,res){
    res.sendFile("/pocetna.html", {root: __dirname});
});
app.get('/unos.html',function(req,res){
    res.sendFile("/unos.html", {root: __dirname});
});
app.get('/sale.html',function(req,res){
    res.sendFile("/sale.html", {root: __dirname});
});
app.get('/css/rezervacija.css',function(req,res){
    res.sendFile("/css/rezervacija.css", {root: __dirname});
});
app.get('/css/pocetna.css',function(req,res){
    res.sendFile("/css/pocetna.css", {root: __dirname});
});
app.get('/css/unos.css',function(req,res){
    res.sendFile("/css/unos.css", {root: __dirname});
});
app.get('/css/sale.css',function(req,res){
    res.sendFile("/css/sale.css", {root: __dirname});
});
app.get('/css/meni.css',function(req,res){
    res.sendFile("/css/meni.css", {root: __dirname});
});
app.get('/kalendar.js',function(req,res){
    res.sendFile("/kalendar.js", {root: __dirname});
});
app.get('/rezervacija.js',function(req,res){
    res.sendFile("/rezervacija.js", {root: __dirname});
});
app.get('/pocetna.js',function(req,res){
    res.sendFile("/pocetna.js", {root: __dirname});
});
app.get('/pozivi.js',function(req,res){
    res.sendFile("/pozivi.js", {root: __dirname});
});
app.get('/zauzeca.json',function(req,res){
    res.sendFile("/zauzeca.json", {root: __dirname});
});
app.get('/img/etf.png',function(req,res){
    res.sendFile("/img/etf.png", {root: __dirname});
});
app.get('/img/sarajevo.jpg',function(req,res){
    res.sendFile("/img/sarajevo.jpg", {root: __dirname});
});
app.get('/img/gradina.jpg',function(req,res){
    res.sendFile("/img/gradina.jpg", {root: __dirname});
});
app.get('/img/mostar.jpg',function(req,res){
    res.sendFile("/img/mostar.jpg", {root: __dirname});
});
app.get('/img/mostar2.jpg',function(req,res){
    res.sendFile("/img/mostar2.jpg", {root: __dirname});
});
app.get('/img/istanbul.jpg',function(req,res){
    res.sendFile("/img/istanbul.jpg", {root: __dirname});
});
app.get('/img/istanbul2.jpg',function(req,res){
    res.sendFile("/img/istanbul2.jpg", {root: __dirname});
});
app.get('/img/pariz.jpg',function(req,res){
    res.sendFile("/img/pariz.jpg", {root: __dirname});
});
app.get('/slike', function(req, res) {
	let tijelo = req.body;
	fs.readdir ("img", (error, files) => {
		if (error) console.log(error);
		var images = [];
		var poc = req.query.pocetna;
		var kraj = req.query.krajnja;
		var i;
		for (i = parseInt(poc); i < parseInt(kraj); i++) {			
			if (files[i] != undefined) {
				images.push("/img/" + files[i]);
			}
		}			
		res.send(images);		
	});
});

app.post('/rezervisi', function(req,res) {
	let tijelo = req.body;
	let noviObjekat = {};
	var mjesecBroj = -1, i;
	var mjeseci = ["Januar", "Februar", "Mart", "April", "Maj", "Juni", "Juli", "August", "Septembar", "Oktobar", "Novembar", "Decembar"];
	if (!mjeseci.includes(tijelo["mjesec"])) res.send("Greška! Mjesec" + tijelo["mjesec"] + " nije u ispravnom formatu!"); // pokušao se poslati nedozvoljeni mjesec (indeks)
	for (var i = 0; i < mjeseci.length; i++) {
		if (mjeseci[i] === tijelo["mjesec"]) {
			mjesecBroj = i;
			break;
		}
	}
	// provjera naziva sale za zahtjeve upucene putem postmana npr
	var sale = ["0-01", "0-02", "0-03", "0-04", "0-05", "0-06", "0-07", "0-08", "0-09", "1-01", "1-02", "1-03", "1-04", "1-05", "1-06", "1-07", "1-08", "1-09", "VA1", "VA2", "MA", "EE1", "EE2"];
	if (!sale.includes(tijelo["sala"])) res.send ("Greška! Neispravan naziv sale!");

	if (tijelo["periodicna"] != 'false') {	
		var dan = tijelo["dan"];
		let prviDan = (new Date(new Date().getFullYear(), mjesecBroj)).getDay(); // vrati broj od 0(ned) do 6(sub)
		if (prviDan == 0) prviDan = 6;
		else prviDan -= 1;
		if (dan == 1) {// odabrali smo prvi dan u mjesecu za rezervaciju 
			dan = prviDan;
		} else {
			dan = ((prviDan + (dan-1))  % 7); // sada je i dan uvijek u intervalu od 0 do 6
		} 
		var danString = dan.toString();
		noviObjekat["dan"] = danString;	
		if (mjesecBroj >= 1 && mjesecBroj <= 5) noviObjekat["semestar"] = "ljetni";
		else if (mjesecBroj >= 9 || mjesecBroj == 0) noviObjekat["semestar"] = "zimski";	
		else {
			// ne može se napraviti periodično zauzeće u ljetnim mjesecima kad nije nastava
			res.send("Greška! Nije moguće napraviti periodično zauzeće izvan semestra!");
		}
		if (tijelo["pocetak"] < tijelo["kraj"]) {
			noviObjekat["pocetak"] = tijelo["pocetak"];
			noviObjekat["kraj"] = tijelo["kraj"];
			noviObjekat["naziv"] = tijelo["sala"];
			noviObjekat["predavac"] = "";
		} else {
			res.send("Greška! Rezervacija nije moguća. Neispravni podaci o rezervaciji!");
		}
	} else {
		var godina = new Date().getFullYear();
		var dvocifreniDan;
		if (tijelo["dan"] <= 9) dvocifreniDan = "0" + tijelo["dan"].toString();
		else dvocifreniDan = tijelo["dan"];
		var datum = dvocifreniDan + "." + (mjesecBroj+1).toString() + "." + godina; 
		noviObjekat["datum"] = datum;
		if (tijelo["pocetak"] < tijelo["kraj"]) {
			noviObjekat["pocetak"] = tijelo["pocetak"];
			noviObjekat["kraj"] = tijelo["kraj"];
			noviObjekat["naziv"] = tijelo["sala"];
			noviObjekat["predavac"] = ""; 
		} else {
			res.send("Greška! Rezervacija nije moguća. Neispravni podaci o rezervaciji!");	
		}
	}

	fs.readFile('zauzeca.json', 'utf8', function readFileCallback(err, data){ 
		if (err){
        	console.log(err);
	    } else {
	    	addData(JSON.parse(data), noviObjekat, res, () => {
	    		res.sendFile('/zauzeca.json', {root: __dirname});
	    	});	    	 
		}
	});
	

});
app.listen(8080);

function addData (data, noviObjekat, res, funkcijaResponse) {
	var periodicna = [];
	var vanredna = [];
	var i;
	var postoji = false;
	for (i = 0; i < data.periodicna.length; i++) {	
		if (noviObjekat["dan"] != undefined && data.periodicna[i].dan == noviObjekat["dan"] && data.periodicna[i].semestar == noviObjekat["semestar"] && data.periodicna[i].naziv == noviObjekat["naziv"]) {
			if ((data.periodicna[i].pocetak >= noviObjekat["pocetak"] && data.periodicna[i].pocetak <= noviObjekat["kraj"]) || data.periodicna[i].kraj >= noviObjekat["pocetak"] && data.periodicna[i].kraj <= noviObjekat["kraj"]) {
				postoji = true;
			}
		} 
		var object = {};
		object["dan"] = data.periodicna[i].dan;
		object["semestar"] = data.periodicna[i].semestar;
		object["pocetak"] = data.periodicna[i].pocetak;
		object["kraj"] = data.periodicna[i].kraj;
		object["naziv"] = data.periodicna[i].naziv;
		object["predavac"] = data.periodicna[i].predavac;
		periodicna.push(object);
	} 
	for (i = 0; i < data.vanredna.length; i++) {
		if (!postoji) {
			if (noviObjekat["datum"] != undefined && data.vanredna[i].datum == noviObjekat["datum"] && data.vanredna[i].semestar == noviObjekat["semestar"] && data.vanredna[i].naziv == noviObjekat["naziv"]) {
				if ((data.vanredna[i].pocetak >= noviObjekat["pocetak"] && data.vanredna[i].pocetak <= noviObjekat["kraj"]) || data.vanredna[i].kraj >= noviObjekat["pocetak"] && data.vanredna[i].kraj <= noviObjekat["kraj"]) {
					postoji = true;
				}
			} 
		}
		var object = {};
		object["datum"] = data.vanredna[i].datum;
		object["pocetak"] = data.vanredna[i].pocetak;
		object["kraj"] = data.vanredna[i].kraj;
		object["naziv"] = data.vanredna[i].naziv;
		object["predavac"] = data.vanredna[i].predavac;
		vanredna.push(object);		
	} 
	if (!postoji) {
		if (noviObjekat["dan"] != undefined) {
			periodicna.push(noviObjekat);
		}
		else {
			vanredna.push(noviObjekat);
		}
		var objekat = {};
		objekat["periodicna"] = periodicna;
		objekat["vanredna"] = vanredna;
		var objektStr = JSON.stringify(objekat);
		fs.writeFile('zauzeca.json', objektStr, function(err, contents) {
			if (err) throw err;
			else funkcijaResponse();
		});

	} else {
		if (noviObjekat["datum"] != undefined)
			res.send("Greška! Nije moguće rezervisati salu " + noviObjekat["naziv"] + " za navedeni datum " + noviObjekat["datum"] + " i termin od " + noviObjekat["pocetak"] + " do " + noviObjekat["kraj"] + "!");
		else 
			res.send("Greška! Nije moguće rezervisati salu " + noviObjekat["naziv"] + " za navedeni dan " + noviObjekat["dan"] + " tokom " + noviObjekat["semestar"] + " semestra i u terminu od " + noviObjekat["pocetak"] + " do " + noviObjekat["kraj"] + "!");
		funkcijaResponse();
	}
}

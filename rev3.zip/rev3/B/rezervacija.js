
    var trenutniMjesec = new Date().getMonth();
    function pozivIscrtavanjuNaprijed(){
        var element = document.getElementById("kalendar");
        trenutniMjesec++;
        Kalendar.iscrtajKalendar(element, trenutniMjesec);
        pozivObojiZauzeca();
        if(trenutniMjesec == 11){
            document.getElementById("buttonPoslije").disabled = true;
            document.getElementById("buttonPrije").disabled = false;
        }
        else{
            document.getElementById("buttonPoslije").disabled = false;
            document.getElementById("buttonPrije").disabled = false;
        }
    }
    function pozivIscrtavanjuNazad(){
        var element = document.getElementById("kalendar");
        trenutniMjesec--;
        Kalendar.iscrtajKalendar(element, trenutniMjesec);
        pozivObojiZauzeca();
        if(trenutniMjesec == 0){
            document.getElementById("buttonPrije").disabled = true;
            document.getElementById("buttonPoslije").disabled = false;
        }
        else{
            document.getElementById("buttonPrije").disabled = false;
            document.getElementById("buttonPoslije").disabled = false;
        }
    }
    function pozivIscrtavanjuOnLoad(){
        var element = document.getElementById("kalendar");
        Kalendar.iscrtajKalendar(element, trenutniMjesec);
    }
    function rezervisi(obj){
        var listaSala = document.getElementById("listaSala");
        var sala = listaSala.options[listaSala.selectedIndex].value;
        var vrijemePocetka = document.getElementById("vrijemPocetak");
        var vrijemeKraja = document.getElementById("vrijemeKraj");
        var periodicno = document.getElementById("periodicno");
        var pocetak = vrijemePocetka.value;
        var kraj = vrijemeKraja.value;
        var c = confirm("Da li zelite da rezervisete ovaj termin?");
        if(c == true){
            if(periodicno.checked == true){
                var dat = new Date(new Date().getFullYear(), trenutniMjesec, obj.children[0].innerHTML);
                day = dat.getDay();
                day = (day===0) ? 7 : day;
                day--;
                var semestar;
                if(trenutniMjesec > 9 || trenutniMjesec == 0) semestar = "zimski";
                else semestar = "ljetni";
                var zauzece1 = new periodicnoZauzece(day, semestar, pocetak, kraj, sala, "");
                posaljiPeriodicnoZauzece(zauzece1);
            }
            else if(periodicno.checked == false){
                var dat = new Date(new Date().getFullYear(), trenutniMjesec, obj.children[0].innerHTML);
                var mj = trenutniMjesec+1;
                var datumStr = dat.getDate() + "." + mj + "." + dat.getFullYear();
                var zauzece2 = new vanrednoZauzece(datumStr, pocetak, kraj, sala, "");
                posaljiVanrednoZauzece(zauzece2);
            }
            
        }
    }
    function pozivUcitavanjuPodataka(){
        //poziv funkciji za ucitavanje podataka sa servera 
        ucitajSaServera(Kalendar.ucitajPodatke);
    }
    function pozivObojiZauzeca(){
        var element = document.getElementById("kalendar");
        var listaSala = document.getElementById("listaSala");
        var sala = listaSala.options[listaSala.selectedIndex].value;
        var vrijemePocetka = document.getElementById("vrijemPocetak");
        var vrijemeKraja = document.getElementById("vrijemeKraj");
        var pocetak = vrijemePocetka.value;
        var kraj = vrijemeKraja.value;
        Kalendar.obojiZauzeca(element, trenutniMjesec, sala, pocetak, kraj);
    }
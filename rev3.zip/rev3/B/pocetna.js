var ucitaneSlike = [];
var i=0;
var j=1;
var k=2;
window.onload = ucitajSlike();
function ucitajSlike(){
    var sl1 = document.getElementById("slika1");
    var sl2 = document.getElementById("slika2");
    var sl3 = document.getElementById("slika3");
    vratiSlike(ucitaneSlike, sl1, sl2, sl3);
}
function prethodne(){
    if(i == 0) return;
    var sl1 = document.getElementById("slika1");
    var sl2 = document.getElementById("slika2");
    var sl3 = document.getElementById("slika3");
    i-=3;
    j-=3;
    k-=3;
    sl1.src = "http://localhost:8080/Photos/" + ucitaneSlike[i];
    sl2.src = "http://localhost:8080/Photos/" + ucitaneSlike[j];
    sl3.src = "http://localhost:8080/Photos/" + ucitaneSlike[k];
    

}
function sljedece(){
    if(ucitaneSlike[i] == undefined || ucitaneSlike[j] == undefined || ucitaneSlike[k] == undefined) return;
    var sl1 = document.getElementById("slika1");
    var sl2 = document.getElementById("slika2");
    var sl3 = document.getElementById("slika3");
    if(k == ucitaneSlike.length-1){
        ucitajSlike();
        i+=3;
        j+=3;
        k+=3;
        return;
    }
    i+=3;
    j+=3;
    k+=3;
    //console.log(i + " " + j + " " + k);
    if(ucitaneSlike[i] != undefined)
    sl1.src = "http://localhost:8080/Photos/" + ucitaneSlike[i];
    else sl1.src = "";
    if(ucitaneSlike[j] != undefined)
    sl2.src = "http://localhost:8080/Photos/" + ucitaneSlike[j];
    else sl2.src = "";
    if(ucitaneSlike[k] != undefined)
    sl3.src = "http://localhost:8080/Photos/" + ucitaneSlike[k];
    else sl3.src = "";
}
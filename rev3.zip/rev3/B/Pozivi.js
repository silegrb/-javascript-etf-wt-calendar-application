function ucitajSaServera(fnCallback){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200){
            var jsonRez = JSON.parse(ajax.responseText);
            fnCallback(jsonRez.zauzeca.periodicna,jsonRez.zauzeca.vanredna);
            pozivObojiZauzeca();
        }
        else if (ajax.readyState == 4)
            fnCallback(ajax.statusText,null);
    }
    ajax.open("POST","http://localhost:8080/rezervacija.html",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send();
 }

function posaljiPeriodicnoZauzece(zauzece){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200){
            ucitajSaServera(Kalendar.ucitajPodatke);
        }
        else if (ajax.readyState == 4 && ajax.status == 201)
        alert(ajax.responseText);

        else if(ajax.readyState == 4){}
    }
    ajax.open("POST","http://localhost:8080/rezervacija.html/periodicno",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(zauzece));
}
function posaljiVanrednoZauzece(zauzece2){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200){
            ucitajSaServera(Kalendar.ucitajPodatke);
        }
        else if (ajax.readyState == 4 && ajax.status == 201)
        alert(ajax.responseText);

        else if(ajax.readyState == 4){}
    }
    ajax.open("POST","http://localhost:8080/rezervacija.html/vanredno",true);
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(zauzece2));
}

function vratiSlike(nizSlika, sl1, sl2, sl3){
    var ajax = new XMLHttpRequest();
    ajax.onreadystatechange = function() {
        if (ajax.readyState == 4 && ajax.status == 200){
            var nazivi = JSON.parse(ajax.responseText);
            if(nazivi.length == 3){
            sl1.src = "http://localhost:8080/Photos/" + nazivi[0];
            sl2.src = "http://localhost:8080/Photos/" + nazivi[1];
            sl3.src = "http://localhost:8080/Photos/" + nazivi[2];
            nizSlika.push(nazivi[0]);
            nizSlika.push(nazivi[1]);
            nizSlika.push(nazivi[2]);
            }
            else if(nazivi.length == 2){
                sl1.src = "http://localhost:8080/Photos/" + nazivi[0];
                sl2.src = "http://localhost:8080/Photos/" + nazivi[1];
                sl3.src = "";
                nizSlika.push(nazivi[0]);
                nizSlika.push(nazivi[1]);
            }
            else if(nazivi.length == 1){
                sl1.src = "http://localhost:8080/Photos/" + nazivi[0];
                sl2.src = "";
                sl3.src = "";
                nizSlika.push(nazivi[0]);
            }
        }
        else if (ajax.readyState == 4 && ajax.status == 201)
        alert(ajax.responseText);

        else if(ajax.readyState == 4){}
    }
    ajax.open("POST","http://localhost:8080/pocetna.html/slike");
    ajax.setRequestHeader("Content-Type", "application/json");
    ajax.send(JSON.stringify(nizSlika));
}

function testni(){
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function(){
        if(xhr.readyState == 4 && this.status == 200){
            //handler(this.response);
            console.log(this.response, typeof this.response);
            var img = document.getElementById("slika1");
            var imageUrl = (window.URL ? URL : webkitURL).createObjectURL(this.response);
            console.log(imageUrl);
            img.src = imageUrl;
        }

    }
    xhr.open('GET', "http://localhost:8080/pocetna.html/slikeTest");
    xhr.responseType = "blob";
    xhr.send();
}
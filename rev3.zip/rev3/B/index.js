const express = require('express');
const bodyParser = require("body-parser");
const fs = require('fs');
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname));

app.get("/", function(req, res){
    res.sendFile(__dirname + "/pocetna.html");
});
app.post("/rezervacija.html", function(req, res){
    res.sendFile(__dirname + "/zauzeca.json");
});
app.get("/pocetna.html/slikeTest", function(req, res){
    res.sendFile(__dirname + "/Photos/Slika1.jpg");
});
app.post("/pocetna.html/slike", function(req, res){
    var ucitaneSlike = [];
    var ucitaneSlike = req.body;
    var nazivi = [];
    fs.readdir("Photos", function(err, filenames) {
        if (err) {
          onError(err);
          return;
        }
        filenames.forEach(element => {
            if(!ucitaneSlike.includes(element)){
                nazivi.push(element.toString());
            }
        });
        var izlaz = [];
      if(nazivi.length>=3)
      for(i=0; i<3; i++){
        izlaz.push(nazivi[i]);
      }
      else izlaz = nazivi;
      res.json(izlaz);
      });
});
app.post("/rezervacija.html/periodicno", function(req, res){
    var dupli = false;
    var obj = req.body;
    fs.readFile('zauzeca.json', (err, data) => {
        if (err) throw err;
        let dataJson = JSON.parse(data);
        var lista = [];
        var listaVanrednih = [];
        listaVanrednih = dataJson.zauzeca.vanredna;
        // potrebno jos dodati datum u poruku za gresku dodavanja sala!
        // moram dodati jos i provjeru sa vanrednim zauzecima kako ne bi doslo do preklapanja
        lista = dataJson.zauzeca.periodicna;
        lista.forEach(element => {
            if(element.dan == obj.dan && element.semestar == obj.semestar && element.naziv == obj.naziv && compareTime(element.pocetak, obj.pocetak, element.kraj, obj.kraj)){ res.status(201).end("Nije moguce rezervisati salu " + obj.naziv + " za navedeni datum _ i termin od " + obj.pocetak + " do " + obj.kraj + "!");
            dupli = true;    
        }
        /*listaVanrednih.forEach(element => {
            if(daLiSuIsti(obj, element)){ res.status(201).end("Nije moguce rezervisati salu " + obj.naziv + " za navedeni datum " + obj.dan + " i termin od " + obj.pocetak + " do " + obj.kraj + "!");
            dupli = true;    
            }
        });*/
        });
        if(!dupli){
        lista.push(obj);
        dataJson.zauzeca.periodicna = lista;
        fs.writeFile('zauzeca.json', JSON.stringify(dataJson), function(){
            res.json(dataJson);
        });
        }
    });
});
app.post("/rezervacija.html/vanredno", function(req, res){
    var dupli = false;
    var obj = req.body;
    fs.readFile('zauzeca.json', (err, data) => {
        if (err) throw err;
        let dataJson = JSON.parse(data);
        var lista = [];
        var listaRedovnih = [];

        listaRedovnih = dataJson.zauzeca.periodicna;
        lista = dataJson.zauzeca.vanredna;
        lista.forEach(element => {
            if(element.datum == obj.datum && element.naziv == obj.naziv && compareTime(element.pocetak, obj.pocetak, element.kraj, obj.kraj)){ res.status(201).end("Nije moguce rezervisati salu " + obj.naziv + " za navedeni datum " + obj.datum + " i termin od " + obj.pocetak + " do " + obj.kraj + "!");
            dupli = true;    
            }
        });
        listaRedovnih.forEach(element => {
            if(daLiSuIsti(element, obj)){ res.status(201).end("Nije moguce rezervisati salu " + obj.naziv + " za navedeni datum " + obj.datum + " i termin od " + obj.pocetak + " do " + obj.kraj + "!");
            dupli = true;    
            }
        });
        if(!dupli){
        lista.push(obj);
        dataJson.zauzeca.vanredna = lista;
        fs.writeFile('zauzeca.json', JSON.stringify(dataJson), function(){
            res.json(dataJson);
        });
        }
    });
});

app.listen(8080);

function daLiSuIsti(element, obj){
    var objDatum = compareDate(obj.datum);
    day = objDatum.getDay();
    day = (day===0) ? 7 : day;
    day--;
    if(day == element.dan && element.naziv == obj.naziv && compareTime(element.pocetak, obj.pocetak, element.kraj, obj.kraj)) return true;
    else return false;
}

function compareTime(pocetak1, pocetak2, kraj1, kraj2){
    //trazeno ponasanje ako je pocetak1<pocetak2 && kraj1>kraj2 || pocetak1<pocetak2 && kraj1<kraj2 || pocetak1>pocetak2 && kraj1<kraj2 
    var satPocetak1 = parseInt(pocetak1[0]+pocetak1[1]+pocetak1[3]+pocetak1[4]);

    var satPocetak2 = parseInt(pocetak2[0]+pocetak2[1]+pocetak2[3]+pocetak2[4]);

    var satKraj1 = parseInt(kraj1[0]+kraj1[1]+kraj1[3]+kraj1[4]);

    var satKraj2 = parseInt(kraj2[0]+kraj2[1]+kraj2[3]+kraj2[4]);


    if(satPocetak2>satPocetak1 && satKraj2<satKraj1) return true;
    else if(satPocetak2<=satPocetak1 && satKraj2>=satKraj1) return true;
    else if(satPocetak2>=satPocetak1 && satPocetak2<=satKraj1) return true;
    else if(satKraj2>=satPocetak1 && satKraj2<=satKraj1) return true;
    else if(satPocetak1 == satPocetak2 && satKraj1 == satKraj2) return true;
    else return false;
}
function compareDate(str1){
    if(str1.charAt(1) == '.'){
        var pom = '0' + str1;
        str1 = pom;
    }
    var dt1   = parseInt(str1.substring(0,2));
    var mon1  = parseInt(str1.substring(3,5));
    var yr1   = parseInt(str1.substring(6,10));
    var date1 = new Date(yr1, mon1-1, dt1);
    return date1;
}
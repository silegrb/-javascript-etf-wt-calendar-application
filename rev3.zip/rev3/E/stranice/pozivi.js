var slikePocetna = [];
var zauzecaPV = [];
function sljedece() {
    if(brojacUcitanihSlika == slikePocetna.length && arhivirane == slikePocetna.length) {
        return; //dosli smo do kraja
    }
    else if(arhivirane < brojacUcitanihSlika) { // ukoliko su slike prethodno ucitane
        var naredneTri="";
        trenutni = trenutni +1;
        naredneTri+=ucitaneSlike[trenutni];
        arhivirane+=3;
        document.getElementById("slike").innerHTML = naredneTri;
    }
    else { //ucitavamo nove slike
        var sadrzaj = document.getElementById("slike");
        Pozivi.prikaziPocetnu(sadrzaj);
    }
}
function prethodne() {
    if(arhivirane <= 3 && trenutni == 0) {
        return; //stigli smo do prvih slika
    }
    var prethdneTri = "";
    trenutni = trenutni - 1;
    prethdneTri += ucitaneSlike[trenutni];
    arhivirane -= 3;
    document.getElementById("slike").innerHTML = prethdneTri;
}
var trenutni = -1;
var brojacUcitanihSlika = 0;
var ucitaneSlike =[];
var arhivirane = 0;
var Pozivi = (function() {
    function prikaziPocetnuImpl(sadrzajPocetne) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {// Anonimna funkcija
            if(ajax.status == 200 && ajax.readyState == 4) {
                var brojac = 0;
                var noviDiv = "";
                slikePocetna = JSON.parse(ajax.responseText);
                while(brojac != 3) {
                    if(brojacUcitanihSlika == slikePocetna.length) { //ucitali smo sve slike
                        break;
                    }
                    else {
                        var novaSlika="<img src=\"" + slikePocetna[brojacUcitanihSlika].url +"\">";
                        noviDiv+=novaSlika;
                        brojacUcitanihSlika++;
                        arhivirane++;
                        brojac++;
                    }
                } 
                ucitaneSlike.push(noviDiv); 
                trenutni++;
                document.getElementById("slike").innerHTML = noviDiv;
            }   
        }
        ajax.open("GET", "pocetnaSlike.json", true);
        ajax.send();
    }
    function prikaziRezervacijeImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function() {// Anonimna funkcija
            if(ajax.status == 200 && ajax.readyState == 4) {

                zauzecaPV = JSON.parse(ajax.responseText);
                var periodicna = [];
                for ( var i = 0; i < zauzecaPV.periodicna.length; i++) {
                    periodicna.push(zauzecaPV.periodicna[i]);
                }
                Kalendar.ucitajPodatke(zauzecaPV.periodicna, zauzecaPV.vanredna);
            }   
        }
        ajax.open("GET", "zauzeca.json", true);
        ajax.send();
    }
    return {
        prikaziPocetnu: prikaziPocetnuImpl,
        prikaziRezervacije: prikaziRezervacijeImpl,
        //upisiZauzeceImpl: upisiZauzece
    }
}());

Pozivi.prikaziRezervacije();
function klik(div) {
    var pocetak = document.getElementById('pocetak').value;
    var kraj = document.getElementById('kraj').value;
    var sala = document.getElementById("sale").options[document.getElementById("sale").selectedIndex].text;
    var periodicna = document.getElementById('periodicna');
    var mjesec = dajMjesec(document.getElementById('mjesec').textContent);
    if(pocetak != '' && kraj != '' && sala != '') {
        var potvrdjeno = confirm("Da li želite rezervisati ovaj termin?");
        var semestar = "";
        if((mjesec>=9 && mjesec<=11) || mjesec == 0) {
            semestar = "zimski";
        }
        if(mjesec>=1 && mjesec<=5) {
            semestar = "ljetni";
        }
        if(potvrdjeno == true) {
            if(periodicna.checked) {
                var dan = Number(div.id) % 7;
                if(dan == 0) {
                    dan = 6;
                }
                else {
                    dan = dan - 1;
                }
                //Pozivi.upisiZauzece(dan,semestar,pocetak,kraj,sala,true);
            }
            else {

            }
        }
        else {
            return;
        }
    }
}
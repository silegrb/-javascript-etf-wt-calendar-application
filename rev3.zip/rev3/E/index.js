const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
app.use(express.static(path.join(__dirname + "/stranice/")));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));

app.get('/pocetnaSlike.json', function(req, res) {
    var json = path.join(__dirname,'/stranice/pocetnaSlike.json');
    res.sendFile(json);
});

app.get('/pocetna.html', function(req, res) {
    fs.readFile('pocetnaSlike.json', 'utf8', (error, data) => {
        if(error) {
            throw error;
        }
        var slike = JSON.parse(data);
        res.setHeader('Content-Type', 'application/json');
        res.sendFile(slike);    
    });
});
app.get('/unos.html', function(req, res) {
    var unos = path.join(__dirname,'/stranice/unos.html');
    res.sendFile(unos);
});
app.get('/zauzeca.json', function(req, res) {
    var json = path.join(__dirname,'/stranice/zauzeca.json');
    res.sendFile(json);
});
app.get('/rezervacija.html', function(req, res) {
    fs.readFile('zauzeca.json', 'utf8', (error, data) => {
        if(error) {
            throw error;
        }
        var zauzeca = JSON.parse(data);
        res.setHeader('Content-Type', 'application/json');
        res.send(zauzeca);    
    });
});
app.get('/sale.html', function(req, res) {
    var sale = path.join(__dirname,'/stranice/sale.html');
    res.sendFile(sale);
});
app.post('/rezervacija.html', function(req,res) {
    fs.readFile('zauzeca.json','utf8', (err, data) => {
        if(err) {
            throw err;
        }
        var zauzeca = JSON.parse(data);
        res.setHeader('Content-Type', 'application/json');
        res.send(zauzeca);   
    });
});
app.listen(8080);
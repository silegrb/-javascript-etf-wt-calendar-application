const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const session = require("express-session");
const app = express();

app.use(express.static(__dirname + "/public"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(
  session({
    secret: "sifra",
    resave: true,
    saveUninitialized: true
  })
);

app.get("/", function(req, res) {
  res.sendFile(__dirname + "/public/html/pocetna.html");
});

app.get("/zauzeca", function(req, res) {
  res.sendFile(__dirname + "/zauzeca.json");
});

app.post("/zauzeca", function(req, res) {
  var dataJson;
  fs.readFile("zauzeca.json", "utf-8", function(error, data) {
    if (error) throw error;
    dataJson = JSON.parse(data);
    var ucitano = req.body;

    var periodicna = false;
    if (req.body.hasOwnProperty("dan")) {
      dataJson.redovna.push(req.body);
      periodicna = true;
      req.body["dan"] = parseInt(req.body["dan"]);
    } else {
      dataJson.vanredna.push(req.body);
    }

    if (!validirajZauzece(ucitano, periodicna)) {
      res.json({ error: "Pogrešni podaci!" });
    } else {
      var greska = false;
      if (periodicna) {
        for (var i = 0; i < dataJson.redovna.length - 1; i++) {
          var rezervacija = dataJson.redovna[i];
          var dan = rezervacija["dan"];
          var semestar = rezervacija["semestar"];
          var pocetak = rezervacija["pocetak"];
          var kraj = rezervacija["kraj"];
          var naziv = rezervacija["naziv"];
          var predavac = rezervacija["predavac"];

          if (
            dan == ucitano["dan"] &&
            semestar == ucitano["semestar"] &&
            pocetak == ucitano["pocetak"] &&
            kraj == ucitano["kraj"] &&
            naziv == ucitano["naziv"] &&
            predavac == ucitano["predavac"]
          ) {
            greska = true;
            break;
          }
        }
      } else {
        for (var i = 0; i < dataJson.vanredna.length - 1; i++) {
          var rezervacija = dataJson.vanredna[i];
          var datum = rezervacija["datum"];
          var pocetak = rezervacija["pocetak"];
          var kraj = rezervacija["kraj"];
          var naziv = rezervacija["naziv"];
          var predavac = rezervacija["predavac"];

          if (
            datum == ucitano["datum"] &&
            pocetak == ucitano["pocetak"] &&
            kraj == ucitano["kraj"] &&
            naziv == ucitano["naziv"] &&
            predavac == ucitano["predavac"]
          ) {
            greska = true;
            break;
          }
        }
      }

      if (greska == false) {
        json = JSON.stringify(dataJson);
        fs.writeFile("zauzeca.json", json, "utf-8", function(error) {
          if (error) throw error;
        });
        res.json({ zauzeca: dataJson });
      } else {
        var poruka;
        if (periodicna) {
          var dani = [
            "ponedjeljak",
            "utorak",
            "srijeda",
            "četvrtak",
            "petak",
            "subota",
            "nedjelja"
          ];
          poruka =
            "Nije moguće periodično rezervisati salu " +
            ucitano["naziv"] +
            " u " +
            dani[ucitano["dan"]] +
            " (" +
            ucitano["semestar"] +
            " semestar) i termin od " +
            ucitano["pocetak"] +
            " do " +
            ucitano["kraj"] +
            "!";
        } else {
          poruka =
            "Nije moguće rezervisati salu " +
            ucitano["naziv"] +
            " za navedeni datum " +
            ucitano["datum"] +
            " i termin od " +
            ucitano["pocetak"] +
            " do " +
            ucitano["kraj"] +
            "!";
        }

        json = JSON.stringify(dataJson);
        res.json({ error: poruka });
      }
    }
  });
});

app.get("/img", function(req, res) {
  fs.readdir("./img", function(error, files) {
    res.write(JSON.stringify(files));
    var posjecenost = new Object();
    for (var i = 0; i < files.length; i++) {
      posjecenost[files[i]] = 0;
    }
    req.session.slike = posjecenost;
    res.send();
  });
});

app.get("/slika", function(req, res) {
  res.sendFile(__dirname + "/img/" + prvaDostupna(req.session.slike));
});

app.listen(8080);

function prvaDostupna(slike) {
  for (var key in slike) {
    if (slike[key] == 0) {
      slike[key] = 1;
      return key;
    }
  }
}

function validirajZauzece(zauzece, periodicnost) {
  if (
    !zauzece.hasOwnProperty("pocetak") ||
    !zauzece.hasOwnProperty("kraj") ||
    !zauzece.hasOwnProperty("naziv") ||
    !zauzece.hasOwnProperty("predavac")
  ) {
    console.log("property");
    return false;
  }
  if (periodicnost) {
    if (!zauzece.hasOwnProperty("dan") || !zauzece.hasOwnProperty("semestar")) {
      console.log("dan / semestar");
      return false;
    }
    if (zauzece.length > 5) return false;

    var dan = zauzece["dan"];
    if (dan < 0 || dan > 6) return false;

    var semestar = zauzece["semestar"];
    if (semestar != "zimski" && semestar != "ljetni") {
      console.log("semestar nije z/lj");

      return false;
    }
  } else {
    if (!zauzece.hasOwnProperty("datum")) return false;
    var datum = zauzece["datum"];
    var regex = /^^([0-2][0-9]|(3)[0-1])(\.)(((0)[0-9])|((1)[0-2]))(\.)\d{4}$/g;
    if (!datum.match(regex)) {
      console.log("neispravan datum");
      return false;
    }
  }
  var pocetak = zauzece["pocetak"];
  var regex1 = /^[0-1][0-9]:[0-5][0-9]$/g;
  var regex2 = /^[2][0-3]:[0-5][0-9]$/g;

  if (!pocetak.match(regex1) && !pocetak.match(regex2)) {
    console.log("neispravan pocetak");
    return false;
  }
  var kraj = zauzece["kraj"];
  if (!kraj.match(regex1) && !kraj.match(regex2)) {
    console.log("neispravan kraj");
    return false;
  }
  //jos trebaju nazivi sala
  var sale = [
    "0-01",
    "1-01",
    "0-02",
    "1-02",
    "0-03",
    "1-03",
    "0-04",
    "1-04",
    "0-05",
    "1-05",
    "0-06",
    "1-06",
    "0-07",
    "1-07",
    "0-08",
    "1-08",
    "0-09",
    "1-09",
    "VA1",
    "VA2",
    "MA",
    "EE1",
    "EE2"
  ];
  return sale.includes(zauzece["naziv"]);
}

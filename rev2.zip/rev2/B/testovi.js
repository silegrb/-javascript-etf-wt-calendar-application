
let assert = chai.assert;
describe('Kalendar', function() {
 describe('iscrtajKalendar()', function() {
   it('mjesc Novembar ima 30 dana', function() {
       var kalendarRef = document.getElementById("kalendar");
     Kalendar.iscrtajKalendar(kalendarRef, 10);
    
     var brojDana = document.getElementsByClassName("dan");
     
    
     assert.equal(brojDana.length, 30,"Broj dana je 30");
   });

   it('mjesc August ima 31 dan', function() {
    var kalendarRef = document.getElementById("kalendar");
  Kalendar.iscrtajKalendar(kalendarRef, 7);
 
  var brojDana = document.getElementsByClassName("dan");
  
 
  assert.equal(brojDana.length, 31,"Broj dana je 31");
});

it('trenutni mjesec je Novembar a prvi dan je petak', function() {
  var kalendarRef = document.getElementById("kalendar");
  var trenutni = new Date().getMonth();
Kalendar.iscrtajKalendar(kalendarRef, trenutni);
var dani = kalendar.getElementsByTagName("td");
var br=0;
for(var i=0; i<dani.length; i++){
  if(dani[i].innerHTML==="") br++;
}


assert.equal(br, 4,"Prvi dan je petak");
});

it('trenutni mjesec je Novembar a posljednji dan je subota', function() {
  var kalendarRef = document.getElementById("kalendar");
  var trenutni = new Date().getMonth();
Kalendar.iscrtajKalendar(kalendarRef, trenutni);
var dani = kalendar.getElementsByTagName("td");
var brPraznih=0;
var brDana=0;
for(var i=0; i<dani.length; i++){
  if(dani[i].innerHTML==="") brPraznih++;
}
if(brPraznih == 4 ){
for(var i=0; i<dani.length; i++){
  if(dani[i].innerHTML != "") brDana++;
}
}


assert.equal(brDana, 30,"Posljednji dan je subota");
});

it('mjesec januar, dani idu od 1 do 31 s pocetkom u utorak', function() {
  var kalendarRef = document.getElementById("kalendar");
  
Kalendar.iscrtajKalendar(kalendarRef, 0);
var dani = kalendar.getElementsByTagName("td");
var brPraznih=0;
var brDana=0;
for(var i=0; i<dani.length; i++){
  if(dani[i].innerHTML==="") brPraznih++;
}
if(brPraznih == 1){
for(var i=0; i<dani.length; i++){
  if(dani[i].innerHTML != "") brDana++;
}
}

assert.equal(brDana, 31,"Prvi dan je utorak");
});

it('mjesec februar ima 28 dana', function() {
  var kalendarRef = document.getElementById("kalendar");
  
Kalendar.iscrtajKalendar(kalendarRef, 1);
var dani = kalendar.getElementsByTagName("td");
var brDana=0;

for(var i=0; i<dani.length; i++){
  if(dani[i].innerHTML != "") brDana++;
}


assert.equal(brDana, 28,"Februar ima 28 dana");
});

it('mjesec juli pocinje u ponedjeljak i ima 31 dan', function() {
  var kalendarRef = document.getElementById("kalendar");
  
Kalendar.iscrtajKalendar(kalendarRef, 6);
var dani = kalendar.getElementsByTagName("td");
var brPraznih=0;
var brDana=0;
for(var i=0; i<dani.length; i++){
  if(dani[i].innerHTML==="") brPraznih++;
}
if(brPraznih==0){
for(var i=0; i<dani.length; i++){
  if(dani[i].innerHTML != "") brDana++;
}
}


assert.equal(brDana, 31,"Prvi dan je utorak");
});
});

});

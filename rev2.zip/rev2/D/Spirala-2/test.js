let assert = chai.assert;
describe('Kalendar', function() {
    describe('iscrtajKalendar()', function() {
      it('should draw 30 days', function() {
        Kalendar.iscrtajKalendar("divCal", 10);
        let dani = document.getElementsByClassName("normal");
        
        assert.equal(30, dani.length,"Broj dana treba biti 30");
      });
      it('should draw 31 days', function() {
          Kalendar.iscrtajKalendar("divCal", 11);
          let dani = document.getElementsByClassName("normal");
        
          assert.equal(31, dani.length,"Broj dana treba biti 31");
        });
      it('1. dan u petak za trenutni mjesec', function() {
          Kalendar.iscrtajKalendar("divCal", 10);
          let daniPrijePrvog = document.getElementsByClassName("before");
          assert.equal(4, daniPrijePrvog.length,"Broj dana prije 1. treba biti 4 što znači da je 1. na petku");
        });
      it('Zadnje dan trenutnog mjeseca je u subotu', function() {
          Kalendar.iscrtajKalendar("divCal", 10);
          let daniPoslijeZadnjeg = document.getElementsByClassName("after");
          assert.equal(1, daniPoslijeZadnjeg.length,"Broj dana poslije zadnjeg dana treba biti 1 što znači da je zadnji dan subota");
        });
      it('Januar ima 31 dan i poćinje sa utorkom!?', function() {
          Kalendar.iscrtajKalendar("divCal", 0);
          let dani = document.getElementsByClassName("normal");
          let daniPrijePrvog = document.getElementsByClassName("before");
          assert.equal(1, daniPrijePrvog.length,"Broj dana prije 1. treba biti 1 što znači da je 1. utorak");
          assert.equal(31, dani.length,"Broj dana Januara");
        });
      it('Februar ima 28 dana i poćinje sa petkom!?', function() {
          Kalendar.iscrtajKalendar("divCal", 1);
          let dani = document.getElementsByClassName("normal");
          let daniPrijePrvog = document.getElementsByClassName("before");
          assert.equal( 4 , daniPrijePrvog.length, "Broj dana prije 1. treba biti 4 što znači da je 1. petak");
          assert.equal(28, dani.length,"Broj dana Februara");
        });
      it('April ima 30 dana i zavrsava sa utorkom!?', function() {
          Kalendar.iscrtajKalendar("divCal", 3);
          let dani = document.getElementsByClassName("normal");
          let daniPoslijeZadnjeg = document.getElementsByClassName("after");
          assert.equal(5, daniPoslijeZadnjeg.length,"Broj dana poslije zadnjeg dana treba biti 5 što znači da je zadnji dan utorak");
          assert.equal(30, dani.length,"Broj dana Aprila");
        });
    });

    describe('obojiZauzeca()', function() {

      it('Pozivanje obojiZauzeca kada podaci nisu učitani:  očekivana vrijednost da se ne oboji niti jedan dan !?', function() {
        Kalendar.iscrtajKalendar("divCal", 10);
        var sala = "";
        var poc = "";
        var kr = "";
        Kalendar.obojiZauzeca(document.getElementById("divCal"), trenutniMjesec, sala, poc, kr);
        let obojeniDani = document.getElementsByClassName("zauzet");
        assert.equal(0, obojeniDani.length);
      });

      it('Pozivanje obojiZauzeca gdje u zauzecima postoje duple vrijednosti za zauzeće istog termina: ' + 
      'očekivano je da se dan oboji bez obzira što postoje duple vrijednosti ', function() {
        Kalendar.iscrtajKalendar("divCal", 10);

        let v = [{
          datum: "11.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
        {
          datum: "11.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        }];
        let p = [{
          dan: 1,
          semestar: "ljetni",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA2",
          predavac: "Vensada"
        }];

        Kalendar.ucitajPodatke(p , v);

        var sala = "VA1";
        var poc = "12:00";
        var kr = "14:00";
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        let obojeniDani = document.getElementsByClassName("zauzet");
        assert.equal(1, obojeniDani.length);
      });

      it('Pozivanje obojiZauzece kada u podacima postoji periodično zauzeće za drugi semestar: očekivano je da se ne oboji zauzeće', function() {
        Kalendar.iscrtajKalendar("divCal", 10);
        let v = [{
          datum: "11.2.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        }];
        let p = [{
          dan: 1,
          semestar: "ljetni",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada"
        }];
        $('#checkbox1').prop('checked', true);
        Kalendar.ucitajPodatke(p , v);
        var sala = "VA1";
        var poc = "12:00";
        var kr = "14:00";
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        let obojeniDani = document.getElementsByClassName("zauzet");
        assert.equal(0, obojeniDani.length);
      });

      it('Pozivanje obojiZauzece kada u podacima postoji zauzeće termina ali u drugom mjesecu: očekivano je da se ne oboji zauzeće', function() {
        Kalendar.iscrtajKalendar("divCal", 10);
        let v = [{
          datum: "11.12.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        }];
        let p = [{
          dan: 1,
          semestar: "ljetni",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada"
        }];
        Kalendar.ucitajPodatke(p , v);
        var sala = "VA1";
        var poc = "12:00";
        var kr = "14:00";
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        let obojeniDani = document.getElementsByClassName("zauzet");
        assert.equal(0, obojeniDani.length);
      });

      it('Pozivanje obojiZauzece kada su u podacima svi termini u mjesecu zauzeti: očekivano je da se svi dani oboje', function() {
        Kalendar.iscrtajKalendar("divCal", 10);
        let v = [
          {
          datum: "1.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "2.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "3.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "4.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "5.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "6.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "7.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "8.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "9.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "10.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "11.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "12.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "13.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "14.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "15.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "16.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "17.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "18.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "19.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "20.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "21.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "22.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "23.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "24.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "25.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "26.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "27.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "28.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "29.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
          {
          datum: "30.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        },
      ];
        let p = [{
          dan: 1,
          semestar: "ljetni",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada"
        }];
        Kalendar.ucitajPodatke(p , v);
        var sala = "VA1";
        var poc = "12:00";
        var kr = "14:00";
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        let obojeniDani = document.getElementsByClassName("zauzet");
        assert.equal(30, obojeniDani.length);
      });

      it(' Dva puta uzastopno pozivanje obojiZauzece: očekivano je da boja zauzeća ostane ista ', function() {
        Kalendar.iscrtajKalendar("divCal", 10);
        let v = [{
          datum: "15.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        }];
        let p = [{
          dan: 1,
          semestar: "ljetni",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada"
        }];
        Kalendar.ucitajPodatke(p , v);
        var sala = "VA1";
        var poc = "12:00";
        var kr = "14:00";
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        let obojeniDani = document.getElementsByClassName("zauzet");
        assert.equal(1, obojeniDani.length);
      });

      it(' Pozivanje ucitajPodatke, obojiZauzeca, ucitajPodatke - drugi podaci, obojiZauzeca: '+
      'očekivano da se zauzeća iz prvih podataka ne ostanu obojena, tj. primjenjuju se samo posljednje učitani podaci  ', function() {
        Kalendar.iscrtajKalendar("divCal", 10);
        let v = [{
          datum: "15.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        }];
        let p = [{
          dan: 1,
          semestar: "ljetni",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada"
        }];
        
        Kalendar.ucitajPodatke(p , v);
        var sala = "VA1";
        var poc = "12:00";
        var kr = "14:00";
        
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        
        Kalendar.iscrtajKalendar("divCal", 10);
        let v2 = [{
            datum: "12.11.2019",
            pocetak: "12:00",
            kraj: "14:00",
            naziv: "VA1",
            predavac: "Vensada Okanovic"
          },
           { datum: "20.11.2019",
            pocetak: "12:00",
            kraj: "14:00",
            naziv: "VA1",
            predavac: "Vensada Okanovic"
          }
        ];
          let p2 = [{
            dan: 1,
            semestar: "ljetni",
            pocetak: "12:00",
            kraj: "14:00",
            naziv: "VA1",
            predavac: "Vensada"
          }];
          Kalendar.ucitajPodatke(p2 , v2);
  
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        
        let obojeniDani = document.getElementsByClassName("zauzet");
        assert.equal(2, obojeniDani.length);
      });


      it('Po izboru: provjera logike da li je zazeto za posebne slučajeve(da li se sati poklapaju)', function() {
        Kalendar.iscrtajKalendar("divCal", 10);
        let v = [{
          datum: "15.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        }];
        let p = [{
          dan: 1,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada"
        }];
        $('#checkbox1').prop('checked', true);
        Kalendar.ucitajPodatke(p , v);
        var sala = "VA1";
        var poc = "11:00";
        var kr = "15:00";
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        let obojeniDani = document.getElementsByClassName("zauzet");
        assert.equal(2, obojeniDani.length);
      });
      
      it('Po izboru: provjera logike da li je zazeto za posebne slučajeve', function() {
        Kalendar.iscrtajKalendar("divCal", 10);
        let v = [{
          datum: "15.11.2019",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada Okanovic"
        }];
        let p = [{
          dan: 1,
          semestar: "zimski",
          pocetak: "12:00",
          kraj: "14:00",
          naziv: "VA1",
          predavac: "Vensada"
        }];
        $('#checkbox1').prop('checked', true);
        Kalendar.ucitajPodatke(p , v);
        var sala = "VA1";
        var poc = "13:00";
        var kr = "15:00";
        Kalendar.obojiZauzeca(document.getElementById("divCal"), 11, sala, poc, kr);
        let obojeniDani = document.getElementsByClassName("zauzet");
        assert.equal(2, obojeniDani.length);
      });
  
    });

   });
var trenutniMjesec = new Date().getMonth();

let Kalendar = (function() {
  let periodicneSale = [];
  let vandredneSale = [];

  function dajNazivMjeseca(mjesec) {
    switch (mjesec) {
      case 0:
        return "Januar";
      case 1:
        return "Februar";
      case 2:
        return "Mart";
      case 3:
        return "April";
      case 4:
        return "Maj";
      case 5:
        return "Juni";
      case 6:
        return "Juli";
      case 7:
        return "August";
      case 8:
        return "Septembar";
      case 9:
        return "Oktobar";
      case 10:
        return "Novembar";
      case 11:
        return "Decembar";
    }
  }

  function validirajDatum(datum) {
    if (typeof datum !== "string") return false;
    if (
      !datum.match(
        /^([0-2][0-9]|(3)[0-1])(\.)(((0)[0-9])|((1)[0-2]))(\.)\d{4}$/i
      )
    )
      return false;
    return true;
  }

  function validirajSemestar(semestar) {
    return semestar === "zimski" || semestar === "ljetni";
  }

  function validirajMjesec(mjesec) {
    if (!Number.isInteger(mjesec)) return false;
    if (mjesec < 0 || mjesec > 11) return false;
    return true;
  }

  function validirajDan(dan) {
    if (!Number.isInteger(dan)) return false;
    if (dan < 0 || dan > 6) return false;
    return true;
  }

  function validirajVriemenskiInterval(pocetak, kraj) {
    if (typeof pocetak !== "string" || typeof kraj !== "string") return false;
    if (!pocetak.match(/^(0[0-9]|1[0-9]|2[0-3]|[0-9]):[0-5][0-9]$/i))
      return false;
    if (!kraj.match(/^(0[0-9]|1[0-9]|2[0-3]|[0-9]):[0-5][0-9]$/i)) return false;
    if (kraj <= pocetak) return false;
    return true;
  }

  function obojiZauzeca(kalendarRef, mjesec, sala, pocetak, kraj) {
    if (validirajMjesec(mjesec) && validirajVriemenskiInterval(pocetak, kraj)) {
      let zauzeteSale = periodicneSale.filter(zauzetaSala => {
        return (
          (((mjesec >= 9 || mjesec < 1) && zauzetaSala.semestar === "zimski") ||
            (mjesec >= 1 &&
              mjesec <= 5 &&
              zauzetaSala.semestar === "ljetni")) &&
          zauzetaSala.naziv === sala
        );
      });

      zauzeteSale.push.apply(
        zauzeteSale,
        vandredneSale.filter(zauzetaSala => {
          datumNiz = zauzetaSala.datum.split(".");
          return (
            new Date(
              datumNiz[1] + " " + datumNiz[0] + " " + datumNiz[2]
            ).getMonth() === trenutniMjesec &&
            Number(datumNiz[2]) === new Date().getFullYear() &&
            zauzetaSala.naziv === sala
          );
        })
      );

      zauzeteSale = zauzeteSale.filter(zauzetaSala => {
        return (
          (zauzetaSala.pocetak < kraj && zauzetaSala.kraj > pocetak) ||
          (zauzetaSala.kraj > pocetak && zauzetaSala.pocetak < kraj)
        );
      });
      let sedmice = kalendarRef.getElementsByClassName("sedmica");
      let dan = 0;

      for (var i = 0; i < sedmice.length; i++) {
        let dani = sedmice[i].getElementsByClassName("dan");
        for (var j = 0; j < dani.length; j++) {
          if (
            dani[j].classList.contains("zauzeta") ||
            dani[j].classList.contains("slobodna")
          )
            dan++;
          if (dani[j].classList.contains("zauzeta")) {
            dani[j].classList.remove("zauzeta");
            dani[j].classList.add("slobodna");
          }
          zauzeteSale.map(sala => {
            if (typeof sala.dan !== "undefined") {
              if (
                j === sala.dan &&
                dani[sala.dan].classList.contains("slobodna")
              ) {
                dani[sala.dan].classList.remove("slobodna");
                dani[sala.dan].classList.add("zauzeta");
              }
            } else {
              if (
                dani[j].classList.contains("slobodna") ||
                dani[j].classList.contains("zauzeta")
              ) {
                if (dan === Number(sala.datum.split(".")[0])) {
                  dani[j].classList.remove("slobodna");
                  dani[j].classList.add("zauzeta");
                }
              }
            }
          });
        }
      }
    }
  }

  function ucitajPodatke(periodicna, vandredna) {
    if (typeof periodicna !== "undefined" && periodicna != null) {
      for (var i = 0; i < periodicna.length; i++) {
        if (
          !validirajDan(periodicna[i].dan) ||
          !validirajSemestar(periodicna[i].semestar) ||
          !validirajVriemenskiInterval(
            periodicna[i].pocetak,
            periodicna[i].kraj
          ) ||
          typeof periodicna[i].naziv === "undefined" ||
          typeof periodicna[i].predavac === "undefined"
        ) {
          periodicna.splice(i, 1);
          i--;
        }
      }
      periodicneSale = periodicna;
    }
    if (typeof vandredna !== "undefined" && periodicna != null) {
      for (var i = 0; i < vandredna.length; i++) {
        if (
          !validirajDatum(vandredna[i].datum) ||
          !validirajVriemenskiInterval(
            vandredna[i].pocetak,
            vandredna[i].kraj
          ) ||
          typeof vandredna[i].naziv === "undefined" ||
          typeof vandredna[i].predavac === "undefined"
        ) {
          vandredna.splice(i, 1);
          i--;
        }
      }
      vandredneSale = vandredna;
    }
  }

  function izbrisiSedmice(kalendarRef) {
    var sedmice = kalendarRef.getElementsByClassName("sedmica");
    while (sedmice.length > 0) sedmice[0].remove();
  }

  function iscrtajKalendar(kalendarRef, mjesec) {
    if (validirajMjesec(mjesec)) {
      let datum = new Date("2019", mjesec);
      let trenutniMjesecKalendar = kalendarRef.childNodes[1];
      kalendarRef.getElementsByTagName("th")[0].innerText = dajNazivMjeseca(
        mjesec
      );
      izbrisiSedmice(kalendarRef);
      let dan = 0;
      let prviDan = datum.getDay() > 0 ? datum.getDay() - 1 : 6;
      let zadnjiDan = new Date(
        datum.getYear(),
        datum.getMonth() + 1,
        0
      ).getDate();

      while (dan < zadnjiDan) {
        var sedmica = trenutniMjesecKalendar.insertRow(-1);
        sedmica.classList.add("sedmica");
        if (!(dan === 0)) sedmica.classList.add("skrivena");
        for (var i = 0; i < 7; i++) {
          var danUSedmici = sedmica.insertCell(-1);
          danUSedmici.classList.add("dan");
          if ((dan === 0 && i >= prviDan) || (dan > 0 && dan < zadnjiDan)) {
            dan++;
            danUSedmici.innerHTML = dan;
            danUSedmici.classList.add("slobodna");
          }
          if (danUSedmici.innerHTML === "")
            danUSedmici.style.borderStyle = "none";
        }
      }
    }
  }
  return {
    obojiZauzeca: obojiZauzeca,
    ucitajPodatke: ucitajPodatke,
    iscrtajKalendar: iscrtajKalendar
  };
})();

Kalendar.ucitajPodatke(
  [
    {
      dan: 2,
      semestar: "zimski",
      pocetak: "10:00",
      kraj: "13:00",
      naziv: "0-01",
      predavac: "Dzan"
    }
  ],
  [
    {
      datum: "6.11.2019",
      pocetak: "12:00",
      kraj: "13:00",
      naziv: "0-01",
      predavac: "Dzan"
    },
    {
      datum: "13.11.2019",
      pocetak: "12:00",
      kraj: "15:00",
      naziv: "0-01",
      predavac: "Dzan"
    }
  ]
);

Kalendar.iscrtajKalendar(document.getElementById("kalendar"), trenutniMjesec);

if (document.getElementById("listaSala")) {
  document.getElementById("listaSala").addEventListener("change", event => {
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      trenutniMjesec,
      document.getElementById("listaSala").options[
        document.getElementById("listaSala").selectedIndex
      ].text,
      document.getElementById("pocetak").value,
      document.getElementById("kraj").value
    );
  });
}

Kalendar.obojiZauzeca(
  document.getElementById("kalendar"),
  trenutniMjesec,
  document.getElementById("listaSala").options[
    document.getElementById("listaSala").selectedIndex
  ].text,
  document.getElementById("pocetak").value,
  document.getElementById("kraj").value
);

document.getElementById("prethodniMjesec").addEventListener("click", event => {
  event.preventDefault();
  if (trenutniMjesec === 1)
    document.getElementById("prethodniMjesec").disabled = true;
  else if (trenutniMjesec === 11)
    document.getElementById("sljedeciMjesec").disabled = false;
  Kalendar.iscrtajKalendar(
    document.getElementById("kalendar"),
    --trenutniMjesec
  );

  Kalendar.obojiZauzeca(
    document.getElementById("kalendar"),
    trenutniMjesec,
    document.getElementById("listaSala").options[
      document.getElementById("listaSala").selectedIndex
    ].text,
    document.getElementById("pocetak").value,
    document.getElementById("kraj").value
  );
});

document.getElementById("sljedeciMjesec").addEventListener("click", event => {
  event.preventDefault();
  if (trenutniMjesec === 10)
    document.getElementById("sljedeciMjesec").disabled = true;
  else if (trenutniMjesec === 0)
    document.getElementById("prethodniMjesec").disabled = false;
  Kalendar.iscrtajKalendar(
    document.getElementById("kalendar"),
    ++trenutniMjesec
  );

  Kalendar.obojiZauzeca(
    document.getElementById("kalendar"),
    trenutniMjesec,
    document.getElementById("listaSala").options[
      document.getElementById("listaSala").selectedIndex
    ].text,
    document.getElementById("pocetak").value,
    document.getElementById("kraj").value
  );
});

if (document.getElementById("pocetak")) {
  document.getElementById("pocetak").addEventListener("change", event => {
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      trenutniMjesec,
      document.getElementById("listaSala").options[
        document.getElementById("listaSala").selectedIndex
      ].text,
      document.getElementById("pocetak").value,
      document.getElementById("kraj").value
    );
  });
}

if(document.getElementById("kraj")){
  document.getElementById("kraj").addEventListener("change", event => {
    Kalendar.obojiZauzeca(
      document.getElementById("kalendar"),
      trenutniMjesec,
      document.getElementById("listaSala").options[
        document.getElementById("listaSala").selectedIndex
      ].text,
      document.getElementById("pocetak").value,
      document.getElementById("kraj").value
    );
  });
}
